package com.txw.designpattern.appearance.model;

/**
 * Created by txw on 2018/2/5.
 */
public interface Phone {

    //打电话
    public void dail();

    //挂断
    public void hangup();

}
