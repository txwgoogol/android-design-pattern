package com.txw.designpattern.interpreter;

import org.junit.Test;

/**
 * 客户类
 * Created by txw on 2018/1/11.
 */
public class Client {

    @Test
    public void main() {
        //根据文法对待特定句子构建对象语法树后解释
    }

}
