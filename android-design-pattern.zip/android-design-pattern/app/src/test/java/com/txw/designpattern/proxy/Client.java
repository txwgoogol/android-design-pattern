package com.txw.designpattern.proxy;

import org.junit.Test;

/**
 * 测试类
 * Created by txw on 2018/1/12.
 */
public class Client {

    @Test
    public void main() {

    }

}
