package com.txw.designpattern.adapter;

/**
 * 类适配器
 * target角色
 * Created by txw on 2018/2/1.
 */
public interface FiveVolt {

    public int getVolt5();

}
