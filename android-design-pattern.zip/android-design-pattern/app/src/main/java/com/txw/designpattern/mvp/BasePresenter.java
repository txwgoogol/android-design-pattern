package com.txw.designpattern.mvp;

/**
 * 中介者 基类
 * Created by txw on 2018/2/13.
 */
public interface BasePresenter {

    void start();

}