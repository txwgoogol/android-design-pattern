package com.txw.designpattern.mvp;

/**
 * 常量
 * Created by txw on 2018/2/15.
 */
public class Constant {

    public static final String BASE_URL = "http://www.weather.com.cn/";

}