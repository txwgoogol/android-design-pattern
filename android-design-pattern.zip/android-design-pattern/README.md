# Android Design Pattern  

[googlesamples todo-mvp](https://github.com/googlesamples/android-architecture/tree/todo-mvp)  
