package com.txw.designpattern.flyweight.model;

/**
 * 展示车票信息
 * Created by txw on 2018/2/4.
 */
public interface Ticket {

    public void showTicketInfo(String bunk);

}