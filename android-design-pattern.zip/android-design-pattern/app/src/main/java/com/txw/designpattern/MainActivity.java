package com.txw.designpattern;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

/**
 * 设计模式
 *
 * @author txw
 * @date 2017/11/8.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

}