package com.txw.designpattern.adapter;

/**
 * adapter角色，需要被转换的对象
 * Created by txw on 2018/2/1.
 */
public class Volt220 {

    public int getVolt220(){
        return 220;
    }

}
